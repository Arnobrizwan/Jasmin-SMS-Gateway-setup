
This is just a placeholder for the needed 'jasmin_smsc_gui/databases' folder
